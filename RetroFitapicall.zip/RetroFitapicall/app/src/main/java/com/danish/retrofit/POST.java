package com.danish.retrofit;

import com.google.gson.annotations.SerializedName;

public class POST {

    private int userID;

    private int id;

    private String title;

    @SerializedName("body")
    private String text;

    public int getUserID() {
        return userID;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }
}

