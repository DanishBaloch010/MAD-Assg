package com.danish.recordsapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Create the basic adapter extending from RecyclerView.Adapter
// Note that we specify the custom ViewHolder which gives us access to our views
class ContactsAdapter (private val mContacts: List<Contacts>) : RecyclerView.Adapter<ContactsAdapter.ViewHolder>() {

    private lateinit var mListener: onItemClickListener
    interface onItemClickListener {
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener: onItemClickListener) {
        mListener = listener
    }




    // ... constructor and member variables
    // Usually involves inflating a layout from XML and returning the holder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactsAdapter.ViewHolder {
        val context = parent.context
        val inflater = LayoutInflater.from(context)
        // Inflate the custom layout
        val contactView = inflater.inflate(R.layout.item_contact, parent, false)
        // Return a new holder instance
        // added the listener for on item click
        return ViewHolder(contactView ,mListener)

    }

    // Involves populating data into the item through holder
    override fun onBindViewHolder(viewHolder: ContactsAdapter.ViewHolder, position: Int) {
        // Get the data model based on position
//        val contact: Contacts = mContacts.get(position)
        val contact: Contacts = mContacts[position]
        // Set item views based on your views and data model
        var textView = viewHolder.idTextView
//        textView.setText(contact.name)
        textView.text = (contact.id)


//        val nameTV = viewHolder.nameTextView
        textView = viewHolder.nameTextView
        textView.text = (contact.name)


//        val descTV = viewHolder.descTextView
        textView = viewHolder.descTextView
        textView.text = (contact.desc)


        viewHolder.titleImage.setImageResource(contact.img_title)


//        val button = viewHolder.messageButton
//        button.text = if (contact.isOnline) "Message" else "Offline"
//        button.isEnabled = contact.isOnline
    }

    // Returns the total count of items in the list
    override fun getItemCount(): Int {
        return mContacts.size
    }

    // Provide a direct reference to each of the views within a data item
    // Used to cache the views within the item layout for fast access
    inner class ViewHolder(itemView: View ,listener: onItemClickListener) : RecyclerView.ViewHolder(itemView) {
        // Your holder should contain and initialize a member variable
        // for any view that will be set as you render a row
        val titleImage: ImageView =  itemView.findViewById<ImageView>(R.id.iv_title_image)
        val idTextView: TextView = itemView.findViewById<TextView>(R.id.tv_id)
        val nameTextView: TextView = itemView.findViewById<TextView>(R.id.tv_name)
        val descTextView: TextView = itemView.findViewById<TextView>(R.id.tv_description)

        init {
            itemView.setOnClickListener {
                listener.onItemClick(adapterPosition)
            }

        }
//        val messageButton: Button = itemView.findViewById<Button>(R.id.message_button)
    }
}