package com.danish.recordsapp

import android.annotation.SuppressLint
import android.provider.Settings.Global.getString
import androidx.core.content.res.TypedArrayUtils.getText

//this is the data class to hold the data.
class Contacts (val id: String, val name: String, val desc: String , var img_title: Int , val details: String) {
    companion object {
        private var serial_num = 0

        @SuppressLint("RestrictedApi")
        fun createContactsList(numContacts: Int): ArrayList<Contacts> {
            val contacts = ArrayList<Contacts>()
            val imageId: Array<Int>
            val names: Array<String>
            val decs: Array<String>

            val alldetails : Array<String>


            imageId = arrayOf(
                R.drawable.a,
                R.drawable.b,
                R.drawable.c,
                R.drawable.d,
                R.drawable.e,
                R.drawable.f,
                R.drawable.g,
                R.drawable.h,
                R.drawable.i
            )

            names = arrayOf(
                "danish",
                "ayaz",
                "atta",
                "hatim",
                "habib",
                "sharukh",
                "khan",
                "amir",
                "faraz"
            )

            decs = arrayOf(
                "BSCS-8th",
                "BSCS-4th",
                "BSCS-2th",
                "BSCS-2th",
                "BSCS-5th",
                "BSCS-3th",
                "BSCS-8th",
                "BSCS-4th",
                "BSCS-1th"
            )

            // TODO:
            // cant find a way to fetch value from this array. this was crashing the app.
//            alldetails = arrayOf(
//                    arrayOf (
//                        R.string.details_a,
//                        R.string.details_b,
//                        R.string.details_c,
//                        R.string.details_d,
//                        R.string.details_e,
//                        R.string.details_f,
//                        R.string.details_g,
//                        R.string.details_h,
//                        R.string.details_i
//                    ).toString()
//                )

            alldetails = arrayOf(
                   "Age 18, Batch 2023, CGPA: 3.6",
                    "Age 16, Batch 2026, CGPA: 2.6",
                    "Age 23, Batch 2025, CGPA: 2.5",
                    "Age 22, Batch 2024, CGPA: 2.5",
                    "Age 17, Batch 2022, CGPA: 3.6",
                    "Age 24, Batch 2021, CGPA: 2.8",
                    "Age 28, Batch 2022, CGPA: 2.9",
                    "Age 19, Batch 2026, CGPA: 3.2",
                    "Age 20, Batch 2028, CGPA: 3.6"
                )

            for( i in imageId.indices) {
//                val name = names[i]
                contacts.add(Contacts("S:No. " + ++serial_num, names[i], decs[i] , imageId[i],
                    alldetails[i]
                ))
            }




//            for (i in 1..numContacts) {
//                contacts.add(Contacts("S:No. " + ++serial_num, "danish", "BSCS-8th" , 1))
//            }
            return contacts
        }



    }
}