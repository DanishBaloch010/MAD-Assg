package com.danish.recordsapp


import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import android.widget.TextView
import com.danish.recordsapp.R.id as id

class DetailsActivity : AppCompatActivity() {

     override fun onCreate(savedInstanceState: Bundle?) {
         super.onCreate(savedInstanceState)
         setContentView(R.layout.details_activity)

         // this color changing code should always be after setContentView
         window.decorView.setBackgroundColor(Color.WHITE)


         val imageDetails: ImageView = findViewById(id.iv_details_activity)

         val idDetails: TextView = findViewById(id.tv_id_details_activity)
         val nameDetails: TextView = findViewById(id.tv_name_details_activity)
         val descDetails: TextView = findViewById(id.tv_desc_details_activity)
         val detailsDetails: TextView = findViewById(id.tv_details_details_activity)

         val bundle : Bundle? = intent.extras

         val img = bundle!!.getInt("img_title")
         val id = bundle.getString("id")
         val name = bundle.getString("name")
         val desc = bundle.getString("desc")
         val details = bundle.getString("details")

         imageDetails.setImageResource(img)
         idDetails.text = id
         nameDetails.text = name
         descDetails.text = desc
         detailsDetails.text = details

     }


}