package com.danish.recordsapp

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.danish.recordsapp.databinding.ActivityMainBinding
import com.danish.recordsapp.ui.home.HomeFragment

class MainActivity : AppCompatActivity() {

//    lateinit var contacts: ArrayList<Contacts>
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        // ...
//        // Lookup the recyclerview in activity layout
//        val rvContacts = findViewById<View>(R.id.rvContacts) as RecyclerView
//        // Initialize contacts
//        contacts = Contacts.createContactsList(20)
//        // Create adapter passing in the sample user data
//        val adapter = ContactsAdapter(contacts)
//        // Attach the adapter to the recyclerview to populate items
//        rvContacts.adapter = adapter
//        // Set layout manager to position the items
//        rvContacts.layoutManager = LinearLayoutManager(this)
//        // That's all!
//    }

    private lateinit var binding: ActivityMainBinding

    // created array list for contacts
    lateinit var contacts: ArrayList<Contacts>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // this color changing code should always be after setContentView
        window.decorView.setBackgroundColor(Color.WHITE)

        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications , R.id.navigation_add_record
            )
        )

        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)



        // my added code for recycler view.
        val rvContacts = findViewById<View>(R.id.rvContacts) as RecyclerView
        // Initialize contacts
        contacts = Contacts.createContactsList(100)
        // Create adapter passing in the sample user data
        val adapter = ContactsAdapter(contacts)

        // Attach the adapter to the recyclerview to populate items
        rvContacts.adapter = adapter

        // Set layout manager to position the items
        rvContacts.layoutManager = LinearLayoutManager(this)
        // That's all!
        //  my added code ends here

        adapter.setOnItemClickListener(object : ContactsAdapter.onItemClickListener{
            override fun onItemClick(position: Int) {
//              Toast.makeText(this@MainActivity, "item num : $position clicked", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@MainActivity , DetailsActivity::class.java)
                intent.putExtra("img_title", contacts[position].img_title)
                intent.putExtra("id", contacts[position].id)
                intent.putExtra("name", contacts[position].name)
                intent.putExtra("desc", contacts[position].desc)
                intent.putExtra("details", contacts[position].details)
                startActivity(intent)
            }

        })
    }
}