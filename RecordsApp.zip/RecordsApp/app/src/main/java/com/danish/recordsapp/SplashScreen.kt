package com.danish.recordsapp

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        // this color changing code should always be after setContentView
        window.decorView.setBackgroundColor(Color.WHITE);

        supportActionBar?.hide()

        Handler(Looper.getMainLooper()).postDelayed({
           val intent = Intent(this@SplashScreen , MainActivity::class.java)
            startActivity(intent)
            // if back is pressed than exit
            finish()
        }, 3000)

    }
}